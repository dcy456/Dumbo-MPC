VERSION = (0, 0, 0, "dev")

__version__ = ".".join(map(str, VERSION))
